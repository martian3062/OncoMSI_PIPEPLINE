from django.urls import path

from .views import (
    dashboard,
    dashboard_metrics_partial,
    history_page,
    history_partial,
    launch_run,
    live_runs_partial,
    milestone_ticker_partial,
)


urlpatterns = [
    path("", dashboard, name="dashboard"),
    path("history/", history_page, name="history-page"),
    path("partials/metrics/", dashboard_metrics_partial, name="dashboard-metrics-partial"),
    path("partials/live-runs/", live_runs_partial, name="live-runs-partial"),
    path("partials/milestones/", milestone_ticker_partial, name="milestone-ticker-partial"),
    path("partials/history/", history_partial, name="history-partial"),
    path("runs/launch/", launch_run, name="launch-run"),
]
